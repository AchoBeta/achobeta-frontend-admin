import{_ as e,c,o as n}from"./CUnfIzp5.js";const o={};function r(t,a){return n(),c("div",null,"意见反馈")}const _=e(o,[["render",r]]);export{_ as default};
