import{r as e}from"./B-e2jNyy.js";function i(r){return e.get({url:"/api/v1/member/list"})}export{i as g};
