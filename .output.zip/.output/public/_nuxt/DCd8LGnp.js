import{_ as e,c,o as n}from"./EutWBD9q.js";const o={};function r(t,s){return n(),c("div",null,"日程安排")}const a=e(o,[["render",r]]);export{a as default};
