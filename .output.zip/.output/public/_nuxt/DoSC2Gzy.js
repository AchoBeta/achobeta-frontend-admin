import{A as o}from"./DSRecueT.js";import{w as t}from"./BS2xta9z.js";const r=t(o);export{r as _};
