import{_ as e,c,o as n}from"./BhRKTyrv.js";const r={};function t(o,a){return n(),c("div",null," 面试管理 ")}const _=e(r,[["render",t]]);export{_ as default};
