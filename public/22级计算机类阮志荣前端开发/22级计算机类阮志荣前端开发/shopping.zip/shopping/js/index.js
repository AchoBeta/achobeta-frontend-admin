const arr = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13]
//随机数
function Random(array, begin) {
  return Math.floor(Math.random() * array.length) + begin
}
// 换一批按钮
const change_goods = document.querySelector('.font_h p')
change_goods.addEventListener('click', function () {
  update()
})
//商品列表的外层盒子
const data_goods = [
  {
    img: `images/font_1.png`,
    title: '审批！rua！',
    price: '￥5699',
  },
  {
    img: `images/font_2.png`,
    title: '护法夜叉',
    price: '￥9999',
  },
  {
    img: `images/font_3.png`,
    title: '小吉祥草王',
    price: '￥9999',
  },
  {
    img: `images/font_4.png`,
    title: '书记官',
    price: '￥9999',
  },
  {
    img: `images/font_5.png`,
    title: '往生堂堂主',
    price: '￥9999',
  },
  {
    img: `images/font_6.png`,
    title: '火花骑士',
    price: '免费',
  },
  {
    img: `images/font_7.png`,
    title: '玉衡星',
    price: '￥5555',
  },
  {
    img: `images/font_8.png`,
    title: '修女',
    price: '￥2344',
  },
  {
    img: `images/font_9.png`,
    title: '富婆',
    price: '￥98989',
  },
  {
    img: `images/font_10.png`,
    title: '砂糖',
    price: '￥1200',
  },
  {
    img: `images/font_11.png`,
    title: '吟游诗人',
    price: '免费',
  },
  {
    img: `images/font_12.png`,
    title: '浪花骑士',
    price: '￥3333',
  },
  {
    img: `images/font_13.png`,
    title: '摩拉',
    price: '￥8',
  },
]
function update() {
  const font_b_ul = document.querySelector('.font_b ul')
  font_b_ul.innerHTML = ``
  let str = ''
  let rand_arr = []
  while (rand_arr.length < 5) {
    const rand = Random(arr, 1);
    let flag = 0;
    if (rand_arr.length == 0)
      rand_arr.push(rand)
    for (let j = 0; j < rand_arr.length; j++) {
      if (rand == rand_arr[j]) {
        flag = 1;
        break;
      }
    }
    if (flag != 1) {
      rand_arr.push(rand)
    }
  }
  for (let i = 0; i < 5; i++) {
    const random = Random(arr, 1)
    str += ` 
  <li><a href="#">
    <img src=${data_goods[rand_arr[i] - 1].img} alt="">
    <h4>${data_goods[rand_arr[i] - 1].title}</h4>
    <p class="value style_red">${data_goods[rand_arr[i] - 1].price}</p>
  </a>
  </li>
  `
  }
  font_b_ul.innerHTML = str
}
//时间模块
const clock = document.querySelector('.recom_hd .clock')
const date = new Date()
const h = date.getHours()
const min = date.getMinutes()
let second = date.getSeconds()
second = second < 10 ? '0' + second : second
clock.innerHTML = `${h}:${min}:${second}`
setInterval(function () {
  const date = new Date()
  let h = date.getHours()
  let min = date.getMinutes()
  let second = date.getSeconds()
  second = second < 10 ? '0' + second : second
  min = min < 10 ? '0' + min : min
  clock.innerHTML = `${h}:${min}:${second}`
}, 1000)
// 关闭广告
const ad = document.querySelector('.ad')
const close = document.querySelector('.close')
close.addEventListener('click', function () {
  ad.style.display = 'none'
})

  //电梯导航
  ; (function () {
    const elevator = document.querySelector('.xtx-elevator')
    //页面尺寸，只读属性 offsetLeft offsetTop
    const entry = document.querySelector('.xtx_entry')

    window.addEventListener('scroll', function () {
      const n = document.documentElement.scrollTop
      elevator.style.opacity = n >= entry.offsetTop ? 1 : 0
    })
    //点击顶部回到顶部
    const backTop = document.querySelector('#backTop')
    backTop.addEventListener('click', () => {
      document.documentElement.scrollTop = 0
    })
  })()
  //点击跳转
  ; (function () {
    const list = document.querySelector('.xtx-elevator-list')
    list.addEventListener('click', (e) => {

      if (e.target.tagName === 'A') {
        //点击激活
        const old = document.querySelector('.xtx-elevator-list .active')
        if (old) old.classList.remove('active')
        e.target.classList.add('active')
        //跳转
        const top = document.querySelector(`.xtx_goods_${e.target.dataset.name}`) ? (document.querySelector(`.xtx_goods_${e.target.dataset.name}`).offsetTop) : 0
        console.log(top);
        document.documentElement.scrollTop = top
      }
    })
  })()
  //滚动到相应位置，对应模块激活
  ; (function () {
    window.addEventListener('scroll', function () {
      const old = document.querySelector('.xtx-elevator-list .active')
      if (old) old.classList.remove('active')
      const font = document.querySelector('.xtx_goods_font')
      const electric = document.querySelector('.xtx_goods_electric')
      const phone = document.querySelector('.xtx_goods_phone')
      // const topic = document.querySelector('.xtx_goods_topic')
      const n = document.documentElement.scrollTop

      if (n >= font.offsetTop && n < electric.offsetTop) {// 选择第一个小盒子
        document.querySelector('[data-name=font]').classList.add('active')
      }
      else if (n >= electric.offsetTop && n < phone.offsetTop) {
        document.querySelector('[data-name=electric]').classList.add('active')
      }
      // else if (n >= brand.offsetTop && n < topic.offsetTop) {
      //   document.querySelector('[data-name=brand]').classList.add('active')
      // }
      else if (n >= phone.offsetTop) {
        document.querySelector('[data-name=phone]').classList.add('active')
      }
    })
  })()
//退出登录

const unlog = document.querySelector('.unlog')

//登录状态
const log = document.querySelector('.log')
const log_out = document.querySelector('#log_out')
log_out.addEventListener('click', function () {
  localStorage.setItem('log_con', 'false')
  unlog.style.display = 'none'
  log.style.display = 'block'
})
  ; (function () {
    if ('true' == localStorage.getItem('log_con')) {
      unlog.style.display = 'block'
      log.style.display = 'none'
    }
    else {
      unlog.style.display = 'none'
      log.style.display = 'block'
    }
  })()

//二级菜单
const mine = document.querySelector('.fr ul li')
mine.addEventListener('mouseenter', function () {

  mine.childNodes[2].style.display = 'block'
})
mine.addEventListener('mouseleave', function () {

  mine.childNodes[2].style.display = 'none'
})
