// 1.tab栏切换 ，二维码页面
const tab_nav = document.querySelector('.tab-nav')
const pane = document.querySelectorAll('.tab-pane')
tab_nav.addEventListener('click', function (e) {
  if (e.target.tagName === 'A') {
    //取消上一个active
    document.querySelector('.active').classList.remove('active')
    //添加现在的
    e.target.classList.add('active')

    //先干掉所有人 for循环
    for (let i = 0; i < pane.length; i++) {
      pane[i].style.display = 'none'
    }
    //让对应的pane显示
    pane[e.target.dataset.id].style.display = 'block'
  }
})

//2.点击提交
//用户名验证登录
const uname_phone = document.querySelector('#uname_phone')
const pw = document.querySelector('#pw')
const form = document.querySelector('form')
const agree = document.querySelector('[name=agree]')
form.addEventListener('submit', function (e) {
  e.preventDefault()
  if (!agree.checked) {
    alert('请勾选同意协议')
  }
  //验证用户名密码
  else {
    if (pw.value == localStorage.getItem('password') && (uname_phone.value == localStorage.getItem('uname') || uname_phone.value == localStorage.getItem('tel'))) {
      localStorage.setItem('log_con', 'true')
      location.href = './index.html'
    }
    else {
      alert('用户名或密码有误！')
    }
  }
})
// 点击图片进入首页
const logo = document.querySelector('.logo')
logo.addEventListener('click', function () {
  location.href = 'index.html'
})
