
//1.验证手机号
const tel = document.querySelector('#tel')
tel.addEventListener('change', verifyTel)
function verifyTel() {
  tel.nextElementSibling.style.opacity = 0
  tel.nextElementSibling.nextElementSibling.style.opacity = 0
  const reg = /^1(3\d|4[5-9]|5[0-35-9]|6[567]|7[0-8]|8\d|9[0-35-9])\d{8}$/
  if (!reg.test(tel.value)) {
    tel.nextElementSibling.style.opacity = 1
    return false
  }
  else {
    tel.nextElementSibling.nextElementSibling.style.opacity = 1
    return true
  }

}
//2.验证用户名
const user = document.querySelector('#user')
user.addEventListener('change', verifyuser)
function verifyuser() {
  user.nextElementSibling.style.opacity = 0
  user.nextElementSibling.nextElementSibling.style.opacity = 0
  const reg = /^\w{6,12}$/
  if (!reg.test(user.value)) {
    user.nextElementSibling.style.opacity = 1
    return false
  }
  else {
    user.nextElementSibling.nextElementSibling.style.opacity = 1
    return true
  }
}

//4.验证验证码
const message = document.querySelector('#message')
message.addEventListener('change', () => {
  const reg = /1/
  if (!reg.test(message.value)) {
    console.log(false);
    return false
  }
  console.log(true);
  return true
})
//5.输入密码
const pw = document.querySelector('#pw')
const safe = document.querySelector('.safe')
pw.addEventListener('change', verifyPw)
function verifyPw() {
  pw.nextElementSibling.style.opacity = 0
  if (pw.value.length < 6) {
    safe.style.display = 'none'
  }
  if (pw.value.length >= 6) {
    safe.style.display = 'block'
    safe.children[0].style.opacity = 1
  }
  if (pw.value.length >= 8) {
    safe.children[1].style.opacity = 1
  }
  if (pw.value.length >= 10) {
    safe.children[2].style.opacity = 1
  }
  const reg = /^\d{6,}$/
  if (!reg.test(pw.value)) {
    pw.nextElementSibling.style.opacity = 1
    return false
  }
  return true
}

//6.确认密码
const sure = document.querySelector('#sure')
sure.addEventListener('change', verifySure)
function verifySure() {
  sure.nextElementSibling.style.opacity = 0
  sure.nextElementSibling.nextElementSibling.style.opacity = 0
  if (sure.value !== pw.value || pw.value === '') {
    sure.nextElementSibling.style.opacity = 1
    return false
  }
  else {
    sure.nextElementSibling.nextElementSibling.style.opacity = 1
    return true
  }
}
// 7.提交
const form = document.querySelector('form')
//7.1 我同意
const user_local = document.querySelector('#user')
const phone_local = document.querySelector('#tel')
const password = document.querySelector('#pw')
const agree = document.querySelector('.agree input')
form.addEventListener('submit', function (e) {
  if (!agree.checked) {
    e.preventDefault()
    alert('请勾选同意协议')
  }
  else {
    if (!verifyuser() || !verifyTel() || !verifyPw() || !verifySure()) {
      alert('请完成输入！')
      e.preventDefault()
    }
    if (verifyuser()) {
      // console.log('user');
      e.preventDefault()
    }
    if (verifyTel()) {
      // console.log('tel');

      e.preventDefault()
    }
    if (verifyPw()) {
      // console.log('pw');

      e.preventDefault()
    }
    if (verifySure()) {
      // console.log('sure');
      e.preventDefault()
    }
  }
  if (verifyuser() && verifyTel() && verifyPw() && verifySure()) {
    e.preventDefault()
    console.log(11);
    localStorage.setItem('password', password.value)
    localStorage.setItem('tel', phone_local.value)
    localStorage.setItem('uname', user_local.value)
    localStorage.setItem('log_con', 'true')
    location.href = 'index.html'
  }
  else {
    e.preventDefault()
    console.log(123);
  }
})
